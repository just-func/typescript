import { JustDuo, JustEmpty, JustMeta, JustUno } from "./Just.js";
//#region ts/toJustValue.d.ts
export declare function toJustValue<V extends void | undefined | JustEmpty>(value?: V, meta?: JustMeta): JustEmpty;
export declare function toJustValue<V extends JustUno<any>>(value?: V, meta?: JustMeta): Readonly<V>;
export declare function toJustValue<V extends JustDuo<any, any>>(value?: V, meta?: JustMeta): Readonly<V>;
export declare function toJustValue<V>(value?: V, meta?: JustMeta): JustUno<V>;
//#endregion
//# sourceMappingURL=toJustValue.d.ts.map