import { JustMeta } from "./Just.js";
//#region ts/testFn.d.ts
/**
 * procedure = function that takes nothing and returns nothing.
 * @see <https://softwareengineering.stackexchange.com/questions/276859/what-is-the-name-of-a-function-that-takes-no-argument-and-returns-nothing>
 */
export declare function procedure(): void;
/**
 * Unit function takes one argument and returns void.
 *
 */
export declare function unit<V>(_v: V): void;
export declare function duo<V, M extends JustMeta>(v: V, m: M): (M | V)[];
//#endregion
//# sourceMappingURL=testFn.d.ts.map