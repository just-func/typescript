import { JustDuo, JustEmpty, JustMeta, JustUno, JustValue } from "./Just.js";
//#region ts/validators.d.ts
/**
 * Type guard for `JustEmpty`
 */
export declare function isJustEmpty(value: unknown): value is JustEmpty;
/**
 * Type guard for `JustUno<V>`
 */
export declare function isJustUno<V>(value: unknown, validator?: (v: JustValue<V>) => unknown): value is JustUno<V>;
/**
 * Type guard for `JustDuo<V, M>`
 */
export declare function isJustDuo<V, M extends JustMeta = JustMeta>(value: unknown, validator?: (v: JustDuo<V, M>) => unknown): value is JustDuo<V, M>;
export declare function isJustValue<V = void, M extends JustMeta | undefined = undefined>(value: unknown, validator?: (value: JustValue<V, M>) => unknown): value is JustValue<V, M>;
//#endregion
//# sourceMappingURL=validators.d.ts.map